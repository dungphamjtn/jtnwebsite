	<p><div id="footer">Footer</div></p>

</div>

<!-- Gọi các Actions tại điểm móc 'wp_footer' -->
<?php wp_footer(); ?>
</body>
</html>