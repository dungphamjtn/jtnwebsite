<?php
	echo "Trong tập tin functions.php";
	
	if ( is_admin() ) echo "Đây là trang wp-admin";
?>