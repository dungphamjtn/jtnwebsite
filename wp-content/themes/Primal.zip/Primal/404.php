<?php get_header(); ?>
<div id="content">
<div class="post">
<div class="title">
<h2>Not Found !</h2>
</div>
<div class="entry"><p>The page you are looking for is not here. Please try a different search or go back to the home page.</p></div>
</div>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>