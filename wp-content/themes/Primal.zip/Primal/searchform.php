
<div id="search">	
	<form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
	<input type="text" name="s" id="s" value="Search ..." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;"/>
	<input id="searchsubmit" type="submit" value="Search" />
</form>
</div>

<div class='clear'></div>	
