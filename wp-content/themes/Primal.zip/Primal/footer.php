<div class="clear"></div>
</div>	
<div id="footer">
	<div class="fcred">
		Copyright &copy; <?php echo date('Y');?> <a href="<?php bloginfo('siteurl'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a> - <?php bloginfo('description'); ?>.<br />
Template <a href="http://www.archystudio.com" title="web development">developed by ArchyStudio</a>. <a href="http://www.designcontest.com/website-design/" title="Web Designers">Web designers</a> sourced for <a href="http://www.fabthemes.com/" title="WordPress Themes - FabThemes.com">FabThemes.com</a>. Distributed by Top <a href="http://topwpthemes.com" title="top wordpress themes">Wordpress theme</a>.
</div>	
<div class='clear'></div>	
<?php wp_footer(); ?>
</div>
<div class='clear'></div>	
</div>
</body>
</html>      